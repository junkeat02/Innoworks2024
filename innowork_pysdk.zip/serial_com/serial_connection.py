import serial
import time

class SerialConnection:
    def __init__(self, port_no):
        self.port_no = port_no
        self.baurate = 115200
        self.sr = None
        self.connection_trials = 3
        self.no_data_bytes = None

    def start_connection(self):
        if self.port_no is not None:
            port = f"COM{self.port_no}"
            try:
                self.sr = serial.Serial(port, self.baurate)
            except Exception:
                if self.connection_trials > 0:
                    self.start_connection()
                    self.connection_trials -= 1
                else:
                    raise("Check the COM connection with the esp32")
        else:
            raise("Please specify the number of the COM connected.")
    
    def read_data(self):
        try:
            self.no_data_bytes = self.sr.in_waiting
        except AttributeError:
            print("No incoming data")
            time.sleep(1)
            self.read_data()
        if self.no_data_bytes > 0 and not None:
            recv_data = self.sr.read(self.no_data_bytes).decode()
            print(recv_data)
            return recv_data


if __name__ == "__main__":
    sr = SerialConnection(port_no=3)
    sr.start_connection()
    while True:
        sr.read_data()