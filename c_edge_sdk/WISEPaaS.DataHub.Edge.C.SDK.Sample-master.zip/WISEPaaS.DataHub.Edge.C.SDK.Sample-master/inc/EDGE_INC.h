/*
* EDGEAGENT_INC.h
*/
#ifndef __EDGEAGENT_INC_H__
#define __EDGEAGENT_INC_H__

#include "EDGE_AGENT_OPTION.h"
#include "EDGE_CONFIG.h"
#include "EDGE_DATA.h"
#include "EDGE_DEVICE_STATUS.h"
#include "CONST.h"

// 3rd
#include "sqlite3.h"
#include "mosquitto.h"

#include "message.h"
//#include "cJSON.h"

//#include "EDGE_DATA.h"
#endif